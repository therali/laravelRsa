## Installation

Laravel 5.4.0 or later is required.

To get the latest version of Laravel Markdown, simply require the project using Composer:

```
$ composer require therali/laravel-rsa
```

